# CS39440: Major Project: Stock Prediction

[Sprints](CS39440%20Major%20Project%20Stock%20Prediction%2049c390b7e42a4b4e98c3dfcbceb95fbc/Sprints%2042523ebc0f7e44b1a6e2903597712db2.md)

[Project Diary](CS39440%20Major%20Project%20Stock%20Prediction%2049c390b7e42a4b4e98c3dfcbceb95fbc/Project%20Diary%202d80b2df5280432c9c10b65d03ab5113.md)

[Supervisor Meetings](CS39440%20Major%20Project%20Stock%20Prediction%2049c390b7e42a4b4e98c3dfcbceb95fbc/Supervisor%20Meetings%20910eda19c7ae47dbaf2f9c8443b92caf.md)

[Report Notes](CS39440%20Major%20Project%20Stock%20Prediction%2049c390b7e42a4b4e98c3dfcbceb95fbc/Report%20Notes%2097e014e1951b40fea91992c23449b64e.md)

[Other](CS39440%20Major%20Project%20Stock%20Prediction%2049c390b7e42a4b4e98c3dfcbceb95fbc/Other%205827117f50d24fb99cf10be09dd67b98.md)