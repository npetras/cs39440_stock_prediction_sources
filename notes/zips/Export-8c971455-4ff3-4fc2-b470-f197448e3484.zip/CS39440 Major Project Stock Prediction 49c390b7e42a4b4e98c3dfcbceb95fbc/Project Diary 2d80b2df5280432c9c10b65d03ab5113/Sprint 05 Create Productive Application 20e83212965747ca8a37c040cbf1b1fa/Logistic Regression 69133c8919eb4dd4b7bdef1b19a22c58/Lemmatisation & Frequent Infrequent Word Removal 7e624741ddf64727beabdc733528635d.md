# Lemmatisation & Frequent/Infrequent Word Removal

Test Accuracy: 0.4603174603174603