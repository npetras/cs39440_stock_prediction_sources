# Lemmatisation & Stopwords

Test Accuracy: 0.4470899470899471