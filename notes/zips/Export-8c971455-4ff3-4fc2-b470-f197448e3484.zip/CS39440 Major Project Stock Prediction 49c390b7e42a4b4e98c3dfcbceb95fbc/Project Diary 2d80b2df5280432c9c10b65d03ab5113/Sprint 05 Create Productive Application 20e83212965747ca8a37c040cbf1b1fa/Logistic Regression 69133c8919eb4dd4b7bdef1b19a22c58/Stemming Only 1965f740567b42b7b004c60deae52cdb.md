# Stemming Only

Test Accuracy: 0.47354497354497355