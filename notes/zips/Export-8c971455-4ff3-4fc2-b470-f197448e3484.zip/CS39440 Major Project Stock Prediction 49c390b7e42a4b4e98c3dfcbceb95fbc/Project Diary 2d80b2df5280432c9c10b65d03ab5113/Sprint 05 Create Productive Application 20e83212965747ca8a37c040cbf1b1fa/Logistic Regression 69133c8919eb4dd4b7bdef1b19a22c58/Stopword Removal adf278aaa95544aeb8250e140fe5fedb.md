# Stopword Removal

Change from None: -0.02
Test Accuracy: 0.4021164021164021