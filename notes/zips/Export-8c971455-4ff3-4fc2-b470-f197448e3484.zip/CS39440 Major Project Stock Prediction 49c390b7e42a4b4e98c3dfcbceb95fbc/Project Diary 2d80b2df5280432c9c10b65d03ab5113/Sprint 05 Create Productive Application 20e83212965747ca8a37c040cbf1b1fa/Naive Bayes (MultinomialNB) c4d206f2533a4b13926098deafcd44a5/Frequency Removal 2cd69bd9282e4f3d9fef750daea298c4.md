# Frequency Removal

Test Accuracy: 0.4523809523809524