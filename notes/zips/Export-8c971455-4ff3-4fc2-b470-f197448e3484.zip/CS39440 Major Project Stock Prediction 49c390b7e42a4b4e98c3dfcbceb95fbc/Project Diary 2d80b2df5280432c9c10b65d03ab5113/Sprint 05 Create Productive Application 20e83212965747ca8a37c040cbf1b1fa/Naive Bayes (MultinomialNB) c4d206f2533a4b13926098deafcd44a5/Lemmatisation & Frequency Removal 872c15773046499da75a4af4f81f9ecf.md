# Lemmatisation & Frequency Removal

Test Accuracy: 0.46296296296296297