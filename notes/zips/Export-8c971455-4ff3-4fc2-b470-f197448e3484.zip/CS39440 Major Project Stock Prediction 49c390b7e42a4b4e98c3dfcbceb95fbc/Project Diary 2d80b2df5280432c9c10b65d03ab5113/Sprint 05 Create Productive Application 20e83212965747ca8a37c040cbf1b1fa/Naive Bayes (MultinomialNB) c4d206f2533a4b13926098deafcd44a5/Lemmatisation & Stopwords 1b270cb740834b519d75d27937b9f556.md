# Lemmatisation & Stopwords

Test Accuracy: 0.48148148148148145