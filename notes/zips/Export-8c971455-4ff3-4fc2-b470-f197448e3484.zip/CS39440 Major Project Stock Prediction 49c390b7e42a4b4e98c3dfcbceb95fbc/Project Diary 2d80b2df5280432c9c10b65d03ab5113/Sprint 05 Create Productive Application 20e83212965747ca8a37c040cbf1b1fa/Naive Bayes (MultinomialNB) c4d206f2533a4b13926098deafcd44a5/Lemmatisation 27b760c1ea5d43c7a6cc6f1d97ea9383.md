# Lemmatisation

Test Accuracy: 0.48677248677248675