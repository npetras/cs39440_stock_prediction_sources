# Stemming Only

Test Accuracy: 0.5158730158730159