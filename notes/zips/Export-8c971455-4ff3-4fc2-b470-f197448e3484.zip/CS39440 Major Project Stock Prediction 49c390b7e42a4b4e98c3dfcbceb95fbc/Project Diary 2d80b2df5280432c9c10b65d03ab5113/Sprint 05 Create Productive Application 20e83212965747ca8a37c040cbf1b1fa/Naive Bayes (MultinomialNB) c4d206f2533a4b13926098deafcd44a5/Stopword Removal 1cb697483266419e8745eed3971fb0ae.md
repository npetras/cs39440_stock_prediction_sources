# Stopword Removal

Change from None: 0.05
Test Accuracy: 0.5