# Basic Count Vectorizer

Test Accuracy: 0.4952
Test F1 Deviation: 0.04461
Test F1 Score: 0.5396
Test Std Deviation: 0.03366
Train Accuracy: 1.0
Train Deviation: 0.0
Train F1: 1.0
Train F1 Deviation: 0.0