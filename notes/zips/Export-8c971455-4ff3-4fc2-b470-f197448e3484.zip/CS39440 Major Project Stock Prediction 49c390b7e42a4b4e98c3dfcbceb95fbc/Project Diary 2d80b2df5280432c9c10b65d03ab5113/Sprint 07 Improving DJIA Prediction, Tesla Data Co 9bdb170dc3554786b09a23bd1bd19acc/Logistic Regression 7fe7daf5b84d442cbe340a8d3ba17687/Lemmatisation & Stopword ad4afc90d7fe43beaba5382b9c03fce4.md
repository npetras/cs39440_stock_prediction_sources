# Lemmatisation & Stopword

Test Accuracy: 0.5123
Test F1 Deviation: 0.04128
Test F1 Score: 0.5588
Test Std Deviation: 0.02551
Train Accuracy: 1.0
Train Deviation: 0.0
Train F1: 1.0
Train F1 Deviation: 0.0