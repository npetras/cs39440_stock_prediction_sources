# Lemmatisation

Test Accuracy: 0.5143
Test F1 Deviation: 0.04331
Test F1 Score: 0.5576
Test Std Deviation: 0.03683
Train Accuracy: 1.0
Train Deviation: 0.0
Train F1: 1.0
Train F1 Deviation: 0.0