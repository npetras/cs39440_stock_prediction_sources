# Lemmatisation, Stopword & Frequency Removal

Test Accuracy: 0.5038
Test F1 Deviation: 0.03961
Test F1 Score: 0.5351
Test Std Deviation: 0.02395
Train Accuracy: 1.0
Train Deviation: 0.0
Train F1: 1.0
Train F1 Deviation: 0.0