# Stemming & Stopwords

Test Accuracy: 0.5133
Test F1 Deviation: 0.0394
Test F1 Score: 0.5598
Test Std Deviation: 0.03271
Train Accuracy: 1.0
Train Deviation: 0.0
Train F1: 1.0
Train F1 Deviation: 0.0