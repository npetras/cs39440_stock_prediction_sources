# Stemming, Stopword & Frequency Removal

Test Accuracy: 0.5002
Test F1 Deviation: 0.03182
Test F1 Score: 0.5331
Test Std Deviation: 0.02012
Train Accuracy: 1.0
Train Deviation: 0.0
Train F1: 1.0
Train F1 Deviation: 0.0