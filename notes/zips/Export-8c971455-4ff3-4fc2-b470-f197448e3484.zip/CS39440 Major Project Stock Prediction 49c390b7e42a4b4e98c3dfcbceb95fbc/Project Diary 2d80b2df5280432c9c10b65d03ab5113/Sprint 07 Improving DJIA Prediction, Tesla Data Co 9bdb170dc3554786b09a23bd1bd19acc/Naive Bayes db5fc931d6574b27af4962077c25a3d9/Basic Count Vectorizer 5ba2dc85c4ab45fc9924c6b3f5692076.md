# Basic Count Vectorizer

Test Accuracy: 0.5012
Test F1 Deviation: 0.02801
Test F1 Score: 0.5933
Test Std Deviation: 0.2228
Train Accuracy: 0.9994
Train Deviation: 0.0003975
Train F1: 0.9994
Train F1 Deviation: 0.0003707