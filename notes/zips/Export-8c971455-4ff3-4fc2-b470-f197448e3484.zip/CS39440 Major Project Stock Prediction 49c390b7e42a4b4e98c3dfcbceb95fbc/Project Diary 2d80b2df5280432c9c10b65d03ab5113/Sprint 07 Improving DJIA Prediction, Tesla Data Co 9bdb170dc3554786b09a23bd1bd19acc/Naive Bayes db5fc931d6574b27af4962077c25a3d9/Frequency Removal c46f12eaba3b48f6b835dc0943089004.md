# Frequency Removal

Test Accuracy: 0.5033
Test F1 Deviation: 0.03907
Test F1 Score: 0.5424
Test Std Deviation: 0.02691
Train Accuracy: 0.8435
Train Deviation: 0.001932
Train F1: 0.8548
Train F1 Deviation: 0.001449