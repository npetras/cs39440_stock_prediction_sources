# Lemmatisation & Stopword

Test Accuracy: 0.5002
Test F1 Deviation: 0.02646
Test F1 Score: 0.5929
Test Std Deviation: 0.02023
Train Accuracy: 0.9995
Train Deviation: 0.0004703
Train F1: 0.9995
Train F1 Deviation: 0.0004387