# Lemmatisation, Stopword & Frequency Removal

Test Accuracy: 0.5173
Test F1 Deviation: 0.03358
Test F1 Score: 0.5617
Test Std Deviation: 0.0289
Train Accuracy: 0.8265
Train Deviation: 0.004845
Train F1: 0.8389
Train F1 Deviation: 0.005386