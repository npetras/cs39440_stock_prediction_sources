# Stemming & Stopwords

Test Accuracy: 0.5038
Test F1 Deviation: 0.03493
Test F1 Score: 0.5823
Test Std Deviation: 0.02741
Train Accuracy: 0.9985
Train Deviation: 0.001166
Train F1: 0.9986
Train F1 Deviation: 0.001084