# Stemming

Test Accuracy: 0.5017
Test F1 Deviation: 0.03496
Test F1 Score: 0.5819
Test Std Deviation: 0.0263
Train Accuracy: 0.9987
Train Deviation: 0.001377
Train F1: 0.9988
Train F1 Deviation: 0.001281