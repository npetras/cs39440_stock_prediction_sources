# Stemming, Stopword & Frequency Removal

Test Accuracy: 0.5183
Test F1 Deviation: 0.01952
Test F1 Score: 0.5659
Test Std Deviation: 0.0179
Train Accuracy: 0.8311
Train Deviation: 0.003114
Train F1: 0.8431
Train F1 Deviation: 0.00248