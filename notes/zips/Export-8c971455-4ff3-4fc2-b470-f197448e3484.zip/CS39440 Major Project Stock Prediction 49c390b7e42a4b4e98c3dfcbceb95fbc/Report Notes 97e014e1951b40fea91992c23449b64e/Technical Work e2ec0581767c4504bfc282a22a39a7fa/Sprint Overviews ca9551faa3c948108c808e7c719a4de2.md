# Sprint Overviews

# Sprint 1: Week 1 to 2.5 (25th Jan - 10th Feb)

- Project Outline, figuring out the concrete detailed focus of the project focus
- Initial Preparation:
    - Choosing the language to use
    - Figuring out the Methodology
    - Reading over the MMP Information
    - Checking how to scrape data from the web
- Learning Python
- Initial Learning and Research into NLP, had little to no knowledge in the area, apart from the little bit I learned from the Machine Learning module
    - Read several artciles
    - Completed a tutorial on the topic — Alexa Tutorial