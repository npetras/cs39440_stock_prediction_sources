# Structure

- Main Content for Technical Work, will be an overview of each Sprint
    - The Sprint's may be grouped
    - Could be named Design, Implementation and Testing Detail
- Design, Implementation and Testing Overview
- May be worth having a Results and Conclusions Section

# Overview

## Design Overview

- Initial Designs, Spikes
- Intermediate Designs
- Final Design

## Implementation Overview

- ?

## Testing Overview

- Testing Approach
- Unit Tests Overview
- Integration Test Overview
- Continous Integration