# Terminology

- Confusion Matrix: how many inputs of that feature confused the classifier to missclassifying a data point