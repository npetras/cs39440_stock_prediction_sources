# 01: Initial Research/Notes

[Implementation Notes](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Implementation%20Notes%2022709029f47c4b00b1a1f690acb50bb4.md)

[Performing Sentiment Analysis](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Performing%20Sentiment%20Analysis%20c9e7debd0cdb485f93112dc058c8889b.md)

[Asset Classes To Use](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Asset%20Classes%20To%20Use%20d076541376354924be0284a388a767d4.md)

[Story Points](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Story%20Points%2030375583a50149689c9faf91b7473967.md)

[Papers/Articles](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Papers%20Articles%20d2e2c0b6483541debc8532be2cd5073e.md)

[Project Methodology & Approach](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Project%20Methodology%20&%20Approach%20f4075c7b6114470a99e7af33027fc46d.md)

[Software Engineering](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Software%20Engineering%20384819fe8bd3445fab30af291b1ed500.md)

[Hypothese/Aim](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Hypothese%20Aim%2010d047c6bb0a4966bfd6e50efc37dd92.md)

[Technology Use](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Technology%20Use%2085cebca204864782853a3241e2267c32.md)

[Stock Market Dictionary](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Stock%20Market%20Dictionary%209347df64d3844ee385f37d5cd5d0c1cb.md)

[Currencies: USD/GBP](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Currencies%20USD%20GBP%20594a0cfa265a4a4a9c90644f52a0e955.md)

[Sentiment Orientation, Pre-processing](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Sentiment%20Orientation,%20Pre-processing%20fe2f944f171b4f21b381b1a6557f9ba4.md)

[Research Questions](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Research%20Questions%205d386917eff4456e8d71c97713727217.md)

[Social Media Research Questions & Ideas](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Social%20Media%20Research%20Questions%20&%20Ideas%202eeafa32da594f40ae3b9fda43cc4242.md)

[NLP, Sentiment Analysis Experimentation](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/NLP,%20Sentiment%20Analysis%20Experimentation%20ef578357a85a4b278e0fd1b882a1a4ec.md)

[Data Scraping](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Data%20Scraping%207260ac0586a840f3b3a7e260d137b764.md)

[Notes for Meeting with Neil Taylor Regarding Epics, Stories and Tasks](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Notes%20for%20Meeting%20with%20Neil%20Taylor%20Regarding%20Epics%2092e457005ca640aa8d524117d018007a.md)

[Review and Retrospective](01%20Initial%20Research%20Notes%209da9f3104b4a403cbcabf565194b4d0c/Review%20and%20Retrospective%209912995b0bf54acdb1342d3fb2ec9c69.md)