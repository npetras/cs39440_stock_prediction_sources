# First Approach

# Currencies

- USD/GBP
- USD/EUR

# Precious Metals

- Gold
- Silver

# Individual Stock

- Tesla?
    - Hot stock, with lots of news
- GM
    - New hot stock
- Apple or other FAANGS
    - Largest company
    - Lots of News, Focus