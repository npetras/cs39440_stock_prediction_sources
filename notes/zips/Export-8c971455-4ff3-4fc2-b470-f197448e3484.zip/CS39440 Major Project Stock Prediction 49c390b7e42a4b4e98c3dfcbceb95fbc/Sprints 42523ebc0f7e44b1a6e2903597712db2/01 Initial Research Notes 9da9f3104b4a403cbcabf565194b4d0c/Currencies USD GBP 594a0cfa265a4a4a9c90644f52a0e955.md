# Currencies: USD/GBP

- USD/GBP - US dollars price vs Pound Sterling price