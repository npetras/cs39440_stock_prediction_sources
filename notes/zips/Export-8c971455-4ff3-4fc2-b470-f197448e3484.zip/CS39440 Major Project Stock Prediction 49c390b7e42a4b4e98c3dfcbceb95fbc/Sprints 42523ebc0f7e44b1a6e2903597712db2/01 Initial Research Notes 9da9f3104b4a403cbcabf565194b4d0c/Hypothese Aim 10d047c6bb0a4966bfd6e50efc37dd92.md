# Hypothese/Aim

- Can Machine Learning Approaches to this problem, make accurate predictions that are not random,  providing value to traders and investors
- Learn underlying patterns of the stock?

- Create classifiers that are applied to assets and evaluate their performance

- Will shed light on the effectiveness of Machine learning approaches for predicting the stock market, particularly when using News Sentiment Analysis
- Maybe insight into short-term vs long-term predictions?