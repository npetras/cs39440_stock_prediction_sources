# Notes for Meeting with Neil Taylor Regarding Epics, Stories and Tasks

- Breaking down large requirements like those in my project outline into individual stories?
    - Cannot see how to do it right now
    - Do you think it will become easier as I progress through the project
    - Is it acceptable to stick to Epics and Tasks, If I cannot break the Epics into Stories?
- Tried to decompose one of the epics into stories
    - Not sure if they will still be too large?
    - Are they still user focused enough?
- Tesla, and Bitcoin Epics?
    - Break down by sentiment analysis, price prediction again
        - Again will this lead to stories too large for a single Sprint?
        - Breaking down further?
- Learning and Research is hard to make customer focused?
    - Mostly technical detail that needs to be done to achieve a requirement (story/epic)