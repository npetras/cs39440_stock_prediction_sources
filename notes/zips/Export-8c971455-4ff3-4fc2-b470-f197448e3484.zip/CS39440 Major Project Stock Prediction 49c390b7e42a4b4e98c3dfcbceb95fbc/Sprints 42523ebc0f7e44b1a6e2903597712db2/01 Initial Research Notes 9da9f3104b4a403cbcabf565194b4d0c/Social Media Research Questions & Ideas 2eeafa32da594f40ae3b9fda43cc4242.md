# Social Media Research Questions & Ideas

- Elon Musk Tweets impact on the cryptocurrency market
    - Dogecoin, Bitcoin
    - Bio change hard to track check?
- Elon Musk Tweets impact on Tesla stock