# Stock Market Dictionary

- Will I have to define this myself, or can I find these patterns in the data
    - Most likely have to mark the items myself

# Positives

- Growth
- Rise
- Pressure Resistance?
- Breaks Through
- Higher
- Up
- Gains

# Negatives

- Stagnation
- Resistance
- Risk?
- Pulling/Pulls Back
- Under pressure

# Neutral

- Resillency?
    - Positive?
- Flat

# USD/GBP Specifics

- USD - Dollar, Greenback, US
- GBP - Pound, Sterling, British
- USD vs Pound