# 02: Background and Analysis

[Spikes into NLP, Sentiment Analysis](02%20Background%20and%20Analysis%20a25872e58a0943c9a6a015e33b85d772/Spikes%20into%20NLP,%20Sentiment%20Analysis%2041c3d615ff9b4989bfd557f09259c290.md)

[Index Analysis](02%20Background%20and%20Analysis%20a25872e58a0943c9a6a015e33b85d772/Index%20Analysis%200b1f191399594f2095be59c8f901b068.md)