# Supervisor Meetings

[Preparation Notes](Supervisor%20Meetings%20910eda19c7ae47dbaf2f9c8443b92caf/Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b.md)

[Minutes (Notes)](Supervisor%20Meetings%20910eda19c7ae47dbaf2f9c8443b92caf/Minutes%20(Notes)%20a50e0c0a51db4615a1bcfb845eddb25a.md)