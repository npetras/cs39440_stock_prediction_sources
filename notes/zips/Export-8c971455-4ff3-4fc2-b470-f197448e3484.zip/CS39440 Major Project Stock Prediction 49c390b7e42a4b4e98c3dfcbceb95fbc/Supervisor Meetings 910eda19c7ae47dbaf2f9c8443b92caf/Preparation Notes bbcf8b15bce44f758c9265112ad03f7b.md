# Preparation Notes

[Week 01](Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b/Week%2001%2084d23fc0769a4e8aa92974f54030e2e8.md)

[Week 02](Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b/Week%2002%20c361a3b7d46c40049e42bf6cf4f12b73.md)

[Week 03](Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b/Week%2003%2016f514af8cce4767916860d5ccbfb175.md)

[Week 04](Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b/Week%2004%200233606dddf54f338db33ef3591f2192.md)

[Week 05](Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b/Week%2005%20dc635225b09b4d539f2ff01c6667f19e.md)

[Week 06](Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b/Week%2006%20242bdd9187ba4007b35c1fb4b1b2fb69.md)

[Week 07](Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b/Week%2007%20e75fb828038540e9b7640d5ec57c890d.md)

[Week 08](Preparation%20Notes%20bbcf8b15bce44f758c9265112ad03f7b/Week%2008%2068d208d84934493399887b00b1854396.md)